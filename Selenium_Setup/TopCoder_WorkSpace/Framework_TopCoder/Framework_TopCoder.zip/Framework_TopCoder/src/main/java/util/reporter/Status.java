package util.reporter;

public enum Status {
	PASS,FAIL,WARN,INFO
}
